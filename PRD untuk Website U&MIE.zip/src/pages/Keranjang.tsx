import { Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { buildWhatsAppUrl, buildCartOrderMessage } from "../config";

export default function Keranjang() {
  const { items, removeItem, updateQty, clearCart, totalItems, totalPrice } = useCart();

  if (items.length === 0) {
    return (
      <div className="min-h-screen pt-24 flex flex-col items-center justify-center text-center px-4">
        <div className="text-7xl mb-4">🛒</div>
        <h2
          className="text-3xl font-bold text-[#FFF8F0] mb-3"
          style={{ fontFamily: "'Syne', sans-serif" }}
        >
          Keranjangmu masih kosong
        </h2>
        <p className="text-[#8C7060] text-sm mb-8">Yuk, tambahkan menu favoritmu dulu!</p>
        <Link
          to="/produk"
          className="bg-[#E8472A] hover:bg-[#d13d22] text-white font-bold px-8 py-3.5 rounded-2xl transition-colors text-sm"
        >
          Lihat Menu
        </Link>
      </div>
    );
  }

  const waMessage = buildCartOrderMessage(
    items.map((i) => ({ name: i.product.name, price: i.product.price, qty: i.qty }))
  );

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-4xl mx-auto px-4 md:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1
            className="text-4xl font-bold text-[#FFF8F0]"
            style={{ fontFamily: "'Syne', sans-serif" }}
          >
            Keranjang
          </h1>
          <p className="text-[#8C7060] text-sm mt-1">{totalItems} item dipilih</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Item list */}
          <div className="lg:col-span-2 flex flex-col gap-3">
            {items.map((item) => (
              <div
                key={item.product.id}
                className="bg-[#2B1D0E] border border-[#3d2510] rounded-2xl p-4 flex gap-4 items-center"
              >
                <Link to={`/produk/${item.product.id}`}>
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 rounded-xl object-cover bg-[#3d2510] shrink-0"
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/produk/${item.product.id}`}>
                    <h3
                      className="text-[#FFF8F0] font-bold text-base leading-tight hover:text-[#F5A623] transition-colors"
                      style={{ fontFamily: "'Syne', sans-serif" }}
                    >
                      {item.product.name}
                    </h3>
                  </Link>
                  <p className="text-[#F5A623] font-semibold text-sm mt-0.5">
                    Rp {item.product.price.toLocaleString("id-ID")}
                  </p>
                  <div className="flex items-center gap-4 mt-2">
                    {/* Qty */}
                    <div className="flex items-center gap-2 bg-[#1A1008] border border-[#3d2510] rounded-xl px-2 py-0.5">
                      <button
                        onClick={() => updateQty(item.product.id, item.qty - 1)}
                        className="w-7 h-7 flex items-center justify-center text-[#FFF8F0] hover:text-[#E8472A] font-bold transition-colors"
                      >
                        −
                      </button>
                      <span className="w-5 text-center text-[#FFF8F0] text-sm font-bold">{item.qty}</span>
                      <button
                        onClick={() => updateQty(item.product.id, item.qty + 1)}
                        className="w-7 h-7 flex items-center justify-center text-[#FFF8F0] hover:text-[#F5A623] font-bold transition-colors"
                      >
                        +
                      </button>
                    </div>
                    <button
                      onClick={() => removeItem(item.product.id)}
                      className="text-[#8C7060] hover:text-[#E8472A] text-xs transition-colors"
                    >
                      Hapus
                    </button>
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[#FFF8F0] font-bold text-base">
                    Rp {(item.product.price * item.qty).toLocaleString("id-ID")}
                  </span>
                </div>
              </div>
            ))}

            <button
              onClick={clearCart}
              className="text-[#8C7060] hover:text-[#E8472A] text-xs transition-colors self-end mt-1"
            >
              Kosongkan keranjang
            </button>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-[#2B1D0E] border border-[#3d2510] rounded-2xl p-5 sticky top-24">
              <h3
                className="text-[#FFF8F0] font-bold text-lg mb-4"
                style={{ fontFamily: "'Syne', sans-serif" }}
              >
                Ringkasan Pesanan
              </h3>

              <div className="flex flex-col gap-2 mb-4">
                {items.map((i) => (
                  <div key={i.product.id} className="flex justify-between text-xs">
                    <span className="text-[#8C7060]">{i.product.name} x{i.qty}</span>
                    <span className="text-[#FFF8F0]/80">Rp {(i.product.price * i.qty).toLocaleString("id-ID")}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-[#3d2510] pt-4 mb-5">
                <div className="flex justify-between items-center">
                  <span className="text-[#FFF8F0] font-semibold text-sm">Total</span>
                  <span
                    className="text-[#F5A623] font-bold text-xl"
                    style={{ fontFamily: "'Syne', sans-serif" }}
                  >
                    Rp {totalPrice.toLocaleString("id-ID")}
                  </span>
                </div>
              </div>

              <a
                href={buildWhatsAppUrl(waMessage)}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#22c55e] text-white font-bold py-4 rounded-2xl transition-colors text-sm w-full"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
                Checkout via WhatsApp
              </a>

              <Link
                to="/produk"
                className="block text-center text-[#8C7060] text-xs mt-4 hover:text-[#FFF8F0] transition-colors"
              >
                + Tambah menu lainnya
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
